#include<stdio.h>

int main()
{
    unsigned int Value = 11;

    printf("Value in decimal format : %d\n",Value);
    printf("Value in octal format : %o\n",Value);
    printf("Value in hexadecimal format : %x\n",Value);

    return 0;
}