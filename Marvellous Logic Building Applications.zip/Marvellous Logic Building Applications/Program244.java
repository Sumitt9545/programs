
class Program244
{
    public static void main(String arg[])
    {
        System.out.println("Jay Ganesh...");
    }
}